## Release Notes

### Sorry, I've not updated this in a long time.

### v1.0.1 (2020-09-30)

- Added cpu usage table for 2D bar charts (-l and -C)

- A lot of internal under-the-hood code improvements

### v1.0.0 (2020-09-29)

- New 'compare' option that generates 2D bar charts from multiple datasources to compare results. This allows you to compare the results of different benchmark parameters or different devices. 

- New/changed command line options to control the format of the label when generating compare graphs. These options are --xlabel-depth and --xlabel-parent. 

- The command line parameters supplied to fio-plot are embedded into the PNG file so you can correlate the image back to fio-plot settings and data sources.

### v0.9.0 (2020-09-29)

Initial release, mostly as a fall-back release in case issues in 1.0.0 are found.
