import fio_plot

if __name__ == '__main__':
    fio_plot.main()
